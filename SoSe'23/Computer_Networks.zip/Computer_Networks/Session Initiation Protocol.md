All telephone calls, video conference calls take place over internet
- people identified by names or email addresses rather than phone numbers
- Can reach callee no matter where callee roams, no matter what IP device callee is currently using

### Services:
1. SIP provides mechanisms for call setup
	- For caller to let callee know she wants to establish a call
	- Callee can agree on media type and encoding
	- End call
	  
2. Determine current IP address of callee
	- map mnemonic identifier to current IP Address
	  
3. Call Management:
	- Add new media streams during calls
	- Change encoding during call
	- Invite others
	- Transfer, hold calls

