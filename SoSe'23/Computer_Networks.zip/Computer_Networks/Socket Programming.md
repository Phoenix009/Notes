
A typical network application consists of a pair of programs — 
a client program and a server program — residing in two different end systems. 

When these two programs are executed, a client process and a server process are created, and these processes communicate with each other by reading from, and writing to, sockets. 

When creating a network application, the developer’s main task is therefore to write the code for both the client and server programs.


### Socket Programming with UDP:

### Socket Programming with TCP:
